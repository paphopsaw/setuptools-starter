import numpy as np


def ref_function():
    return np.zeros(10)